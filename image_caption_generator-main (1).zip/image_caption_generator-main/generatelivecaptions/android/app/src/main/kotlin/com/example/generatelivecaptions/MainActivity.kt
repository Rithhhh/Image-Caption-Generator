package com.example.generatelivecaptions

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
